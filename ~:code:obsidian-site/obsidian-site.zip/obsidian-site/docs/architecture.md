# Architecture

> Living document. Each subagent appends to its relevant section as it completes work.

## Status: Phase 0 — pre-build

No code yet. This file is a stub. The orchestrator and subagents will populate the sections below as Phase 1 begins.

---

## 1. Stack decisions

(to be populated by `nuxt-shell-architect` in Phase 1)

- Framework:
- Bundler:
- Styling approach:
- Font hosting:
- CMS:
- Deployment target:

## 2. Design token system

(to be populated by `nuxt-shell-architect`)

- Token file location:
- Naming convention:
- Mobile override strategy:

## 3. Layout shell

(to be populated by `nuxt-shell-architect`)

- Layout component tree:
- Persistent nav components:
- WebGL canvas mounting strategy:

## 4. 3D narrative engine

(to be populated by `webgl-scene-engineer` in Phase 2)

- Scene management:
- Camera path source:
- Scroll-to-state pipeline:
- Asset compression pipeline:
- Reduced-motion fallback strategy:

## 5. Content layer

(to be populated by `narrative-content-architect` in Phase 2)

- Sanity project ID:
- Schema list:
- ISR strategy:
- Voice register enforcement:

## 6. Component library

(to be populated by `ui-component-craftsman` in Phase 2)

- Component inventory:
- State coverage:
- Icon system:
- Mark devices:

## 7. Mobile narrative

(to be populated by `mobile-narrative-designer` in Phase 3)

- Breakpoint strategy:
- Act-by-act mobile treatment:
- Performance budget:

## 8. Brand compliance

(maintained by `brand-compliance-auditor` across all phases)

- Audit cadence:
- CI gates:
- Deviations log: `/docs/brand-deviations.md`

## 9. Performance budget

| Surface | Metric | Target |
|---|---|---|
| Desktop initial JS (gzip) | ≤ 250 KB | |
| Mobile initial JS (gzip) | ≤ 180 KB | |
| Each GLB scene (Draco) | ≤ 350 KB | |
| Desktop LCP (Slow 4G) | ≤ 2.5 s | |
| Mobile LCP (Slow 4G + 4× CPU) | ≤ 2.5 s | |
| Lighthouse Desktop Performance | ≥ 85 | |
| Lighthouse Mobile Performance | ≥ 80 | |
| Lighthouse Accessibility | 100 | |
| Lighthouse SEO | ≥ 95 | |
| Scroll FPS (M2 MacBook Air) | 60 sustained | |
