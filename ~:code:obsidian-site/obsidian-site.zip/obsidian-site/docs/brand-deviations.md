# Brand Deviations Log

Maintained by `brand-compliance-auditor`. Every deliberate deviation from `/brand/obsidian-brand-guidelines.pdf` is recorded here with rationale, scope, and review date.

> **No deviation is permanent.** Every entry below is reviewed at the next phase gate. Deviations to rules marked "Immutable" in brand section 4.4 are never granted — period.

---

## Format

```
### DEV-NNN — Short title
- **Filed by:** {agent-name}
- **Date:** YYYY-MM-DD
- **Rule cited:** Brand doc section X.Y, exact quote
- **Conflict:** What the build requires that the rule appears to forbid
- **Resolution:** What we're doing instead, why it preserves brand spirit
- **Scope:** Where this deviation applies (file paths, components, content surfaces)
- **Review date:** Next phase gate / scheduled review
- **Status:** APPROVED / REJECTED / UNDER REVIEW
- **Approver:** brand-compliance-auditor (final authority)
```

---

## Active deviations

### DEV-001 — WebGL camera-flythrough vs. "no parallax on background images"
- **Filed by:** orchestrator (pre-build, anticipated)
- **Date:** 2026-05-12
- **Rule cited:** Brand section 2.6 Motion Principles — *"Never: parallax scrolling effects on background images."*
- **Conflict:** The reference Hut 8 site (which we are replicating structurally) uses a scroll-driven Three.js camera that moves through 3D scenes. A strict reading of "parallax on background images" could be interpreted to forbid this.
- **Resolution:** A scrubbed WebGL camera move through a rendered 3D scene is not parallax. Parallax is a CSS-side mimicry technique (`background-attachment: fixed`, `translateY` on background images proportional to scroll). The WebGL camera is a first-class 3D scene update — semantically and technically a different operation. The brand spirit (no decorative motion, no cheap scroll tricks) is preserved: every camera move corresponds to a narrative beat, every scene change is meaningful, no decorative imagery moves at a different rate than its container.
- **Scope:** `components/WebGLCanvas.vue`, `composables/useScrollScene.ts`, all three GLB scenes.
- **What is still forbidden under this deviation:** CSS `background-attachment: fixed`, scroll-coupled `translateY` on any `<img>` or `background-image`, any decorative photo or texture that moves relative to its surroundings on scroll. The auditor enforces these.
- **Review date:** End of Phase 2.
- **Status:** APPROVED — anticipated, documented in advance.
- **Approver:** brand-compliance-auditor.

---

## Rejected deviations

(none yet)

---

## Historical / closed deviations

(none yet)
